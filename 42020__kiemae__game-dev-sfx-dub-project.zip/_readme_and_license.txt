Pack downloaded from Freesound
----------------------------------------

"Game Dev SFX Dub Project"

This Pack of sounds contains sounds by the following user:
 - KieMae ( https://freesound.org/people/KieMae/ )

You can find this pack online at: https://freesound.org/people/KieMae/packs/42020/


Licenses in this Pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this Pack
-------------------

  * 761863__kiemae__button_click.wav.wav
    * url: https://freesound.org/s/761863/
    * license: Creative Commons 0


